package itsaMAZEing;

public enum LegalMoves {
	up,
	down,
	left,
	right
}
