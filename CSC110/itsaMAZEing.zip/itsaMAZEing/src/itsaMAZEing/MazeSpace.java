package itsaMAZEing;

public enum MazeSpace {
	wall,space
}
