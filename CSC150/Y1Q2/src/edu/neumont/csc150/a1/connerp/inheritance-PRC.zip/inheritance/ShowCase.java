package edu.neumont.csc150.a1.connerp.inheritance;

public class ShowCase {

	public static void main(String[] args) {
		Vehicle astro = new Vehicle(8, "Astro", "Chevy");
		Vehicle silverado = new Truck(5, "Silverado", "Chevy", 5500);
		
		System.out.println(astro);
		System.out.println(silverado);
	}

}
