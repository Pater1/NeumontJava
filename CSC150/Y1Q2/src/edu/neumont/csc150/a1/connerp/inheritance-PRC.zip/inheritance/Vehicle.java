package edu.neumont.csc150.a1.connerp.inheritance;

public class Vehicle {
	protected final int pasengerCapacity;
	protected final String make, model;
	
	public Vehicle(int capacity, String make, String model){
		this.pasengerCapacity = capacity;
		this.make = make;
		this.model = model;
	}
	

	@Override
	public String toString(){
		return "" + make + ", " + model + ": pasenger capacity: " + pasengerCapacity;
	}
}
