package edu.neumont.csc150.a1.connerp.inheritance;

public class Truck extends Vehicle{
	protected final int towCapacity;
	
	public Truck(int capacity, String make, String model, int towCapacity){
		super(capacity, make, model);
		this.towCapacity = towCapacity;
	}
	
	@Override
	public String toString(){
		return super.toString() + " towing capacity: " + towCapacity;
	}
}
