package edu.neumont.csc150.a6.connerp;

public interface IStoplightListener {
	void LightChanged(StoplightState changedTo);
}
