package edu.neumont.csc150.a6.connerp;

public interface ITickListener {
	void DelayEnded();
}