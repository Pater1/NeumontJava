package edu.neumont.csc150.a4.connerp;

public enum StoplightState {
	Red(5000),
	Yellow(500),
	Green(10000);
	
	int milliDelay;
	private StoplightState(int i){
		milliDelay = i;
	}
	
	public int GetDelay(){
		return milliDelay;
	}
}