package edu.neumont.csc150.a4.connerp;

public interface IStoplightListener {
	void LightChanged(StoplightState changedTo);
}
