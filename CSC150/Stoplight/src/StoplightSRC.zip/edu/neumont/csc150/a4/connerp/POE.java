package edu.neumont.csc150.a4.connerp;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class POE {

	public static void main(String[] args) {
		POEFrame stop = new POEFrame();
		stop.setVisible(true);
	}

	private static class POEFrame extends JFrame{
		public POEFrame(){
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setSize(new Dimension(640, 480));
			setPreferredSize(new Dimension(640, 480));
			
			Stoplight light = new Stoplight();
			setContentPane(light);
			light.subscribe(new StoplightConsoleAlert());
			
			pack();
		}
		
		
	}
}