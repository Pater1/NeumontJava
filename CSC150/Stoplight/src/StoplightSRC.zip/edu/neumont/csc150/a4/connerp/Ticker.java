package edu.neumont.csc150.a4.connerp;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JComponent;
import javax.swing.Timer;

public class Ticker {
	private static ArrayList<TimerContainer> timers = new ArrayList<TimerContainer>();
	
	public static void DelayStart(int milli, ITickListener listener){
		TimerContainer t = findTimer();
		t.TickStart(milli, listener);
	}
	
	private static TimerContainer findTimer(){
		for(TimerContainer t : timers){
			if(!t.isInUse()) return t;
		}
		
		TimerContainer t = new TimerContainer();
		timers.add(t);
		return t;
	}
	
	private static class TimerContainer implements ActionListener{
		private ITickListener listener;
		private Timer time = new Timer(0, this);
		private boolean inUse = false;
		
		public boolean isInUse(){
			return inUse;
		}
		
		public TimerContainer(){}
		public void TickStart(int milli, ITickListener listener){
			TimerSetup(milli, listener);
			
			inUse = true;
			time.start();
		}
		
		private void TimerSetup(int milli, ITickListener listener){
			time.setDelay(milli);
			this.listener = listener;
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			listener.DelayEnded();
			inUse = false;
		}
	}
}